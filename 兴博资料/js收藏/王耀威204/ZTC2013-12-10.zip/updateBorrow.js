

function testBeforeInokeCallBackMethod_data(datasArray)//自定义按钮回调方法
{
	if(datasArray==null||datasArray.length==0) 
	{
		alert('没有取到报表数据');
		return false;//没有取到报表数据，则不调用后台操作
	}
	return true;
}
function testInvokeCallbackMethod_data(datasObj)//自定义按钮 回调方法
{  


	var componentguid=getComponentGuidById(datasObj.pageid, datasObj.componentid);//先取到组件GUID
	var datasArr=null;
	if(WX_ALL_SAVEING_DATA!=null) datasArr =WX_ALL_SAVEING_DATA[componentguid];
	if(datasArr!=null&&datasArr.length>0)
	{  
	      parent.window.location.reload();
	      //alert(datasObj.returnValue);
	}else
	{
		alert('无参数');
	}
	
	if(parent.artD) {
		parent.artD.close();
    }
}
