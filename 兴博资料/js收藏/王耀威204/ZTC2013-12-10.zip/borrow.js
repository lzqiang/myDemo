
var sum=000000;
function dispatchBorrow(){/*单击办证时新添加一个tab*/
  //alert('办证页面');
    parent.parent.addTab('report.xb?PAGEID=carBorrowInvoke1','车辆借调', sum,'合肥渣土车GPS监控管理系统 -> 单车办证 -> 车辆借调','tab_blank.png');
    sum=sum+1;
}

function guihuan(){
   var value=parent.parent.$('#rUserid').text();
   if('10004928'==value||'10005038'==value||'10004922'==value||'10000001'==value){
       $('#btnBorrow').show();
   }else{
       $('#btnBorrow').hide();
   }

}

  $(function(){
	   guihuan();
	});
//多选回调方法
var carIdArr="";
function selBottonBorrowCallback(pageid,reportid,selectedTrObjArr,deselectedTrObjArr) {
	var allSelectedTrObjsArr=getAllSelectedTrObjs(pageid,reportid);//页面id 报表id
	 carIdArr = getCarIdValArr(allSelectedTrObjsArr);
}
//遍历值
function getCarIdValArr(trObjsArr)
{
  
	var carIdValArr = [];//存放借调id
	var carNum=[];//车牌号码
	var carID=[];//车辆id
	var val=[];
	if(trObjsArr==null||trObjsArr.length==0) 
		return '';
	for(var i=0;i<trObjsArr.length;i++)
	{
		var tdChilds=trObjsArr[i].getElementsByTagName('TD');
		for(var j=0;j<tdChilds.length;j++)
		{  
			var name=tdChilds[j].getAttribute('oldvalue_name');//获取当前列对应的<col/>的列名
			var value=tdChilds[j].getAttribute('oldvalue');//获取选中行的当前列的数据
			 
			if(name&&name!=''&&'BORROW_ID'==name)
			{
				carIdValArr.push(value);
			}else if(name&&name!=''&&'CAR_LICENSE'==name)
			{
			   carNum.push(value);
			}else if(name&&name!=''&&'CARID'==name)
			{
			   carID.push(value);
			}else if(name&&name!=''&&'STATUS'==name&&value=='已归还'){
			
			  try{searchReportData('carBorrowInvokeServer','report2')}catch(e){}
			   art.dialog({
			      title:'提示',
			      width: '30em',
		          height: 75,
			      //time: 3,
			      content: '<font size="3">您选择的车辆已归还！请重新选择</font>'
			    });
			  return ;
			}
		}
	}
	val.push(carIdValArr);//借调归还数组集合
	val.push(carNum);//车牌号码
	val.push(carID);//车辆id
	return val;
}


function sendBack(){

 art.dialog({
	     title:'提示',
	      width: '20em',
          height: 75,
	     // time: 3,
	     content: '<font size="3">请选择修改项</font>'
	      });

if(!carIdArr||carIdArr.length<1){//未选中修改项
	     art.dialog({
	     title:'提示',
	      width: '20em',
          height: 75,
	     // time: 3,
	     content: '<font size="3">请选择归还项</font>'
	      });
	    return;  
   }else {
       //invokeServerActionForReportData('carBorrowInvokeServer','report2','com.xingbo.muckcar.callback.BorrowRemoveServerCallBack',{name:'SELECTEDROW',value:true},{ opt_id:parent.parent.$('#rUserid').text()},true,testBeforeInokeCallBackMethod1,testInvokeCallbackMethod1);
       //归还借调
       //<update  pageurl="report{updateBack.backReport}" popupparams="{width:650,height:400,title:''}" urlparams="borrow_id=@{BORROW_ID}"/>
	alert(carIdArr[0].toString());
	art.dialog({
	title:'单车办证信息列表',
    width: '100%',
    height: '100%',
    left: '0%',
    top: '0%',
    padding:0,
    fixed: true,
    resize: false,
    drag: false,
    content: "<iframe src='report.xb?PAGEID=backReport&BORROW_ID="+carIdArr[0].toString()+"' id='record_id' height='100%' width='100%' frameborder='0'></iframe>"
   });	
  }
}

